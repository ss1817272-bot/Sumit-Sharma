# ज्ञान वाला जादुई सफर — Android प्रोजेक्ट

यह प्रोजेक्ट आपकी अपलोड की गई `ai_studio_code.html` को Android WebView ऐप के रूप में पैकेज करता है। मूल HTML को `app/src/main/assets/index.html` में रखा गया है। ऐप का JavaScript और `localStorage` WebView में चालू है, ताकि गेम की स्थानीय प्रगति/सेटिंग्स सहेजी जा सकें।

## APK बनाने के लिए
1. कंप्यूटर पर Android Studio का वर्तमान stable संस्करण इंस्टॉल करें।
2. Android Studio में **Open** चुनें और इस ZIP से निकला `GyanWalaJaduiSafarAndroid` फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें और Android SDK Platform 36 इंस्टॉल करने के लिए कहे तो स्वीकार करें।
4. फोन में Developer options और USB debugging चालू कर के फोन जोड़ें, या Android Emulator चलाएँ। पहले ऐप चलाकर टेस्ट करें।
5. टेस्ट APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**। बनने पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा। यह टेस्ट/साइडलोड के लिए है।

## Google Play Store के लिए
1. Android Studio में **Build > Generate Signed Bundle / APK** चुनें।
2. **Android App Bundle** चुनें, नया keystore बनाकर सुरक्षित जगह पर रखें, फिर release bundle बनाएँ। Keystore/password खोने पर अपडेट करना मुश्किल हो सकता है; इन्हें किसी से साझा न करें।
3. Google Play Console में app बनाएँ, store listing, screenshots, app icon, support email, privacy policy URL, Data safety, content rating और target audience भरें।
4. Release AAB अपलोड करें और Play Console की सभी warnings/policy declarations हल करें।
5. नए personal developer accounts (13 Nov 2023 के बाद बने) को production access के लिए कम-से-कम 12 testers का 14 लगातार दिनों का closed test पूरा करना होता है। नियम आपके खाते के प्रकार/स्थिति के अनुसार जाँचें।

## प्रकाशन से पहले ज़रूरी जाँच
- ऐप बच्चों को लक्षित लग सकती है; Play Console में target audience सही घोषित करें और लागू Families policy का पालन करें।
- ऐप में कोई login, analytics या ad SDK नहीं जोड़ा गया है और manifest में इंटरनेट permission नहीं है। अगर बाद में ऑनलाइन सुविधाएँ जोड़ें तो privacy policy और Data safety को दोबारा जाँचें।
- Play Store पर प्रकाशित करने के लिए Google Play developer account चाहिए; आधिकारिक जानकारी के अनुसार एक बार की US$25 registration fee है।
- Package ID `com.gyanwalajaduisafer.app` रखा गया है। पहली release के बाद इसे बदलना सामान्यतः नई ऐप जैसा माना जाएगा, इसलिए publish करने से पहले अपनी पसंद का स्थायी ID तय करें।
- यह स्रोत प्रोजेक्ट है, पहले से compiled APK/AAB नहीं। Build करने के लिए Android Studio और Android SDK की ज़रूरत है।
